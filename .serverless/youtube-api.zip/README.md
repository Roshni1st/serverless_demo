# to start project
serverless offine start

# to deploy lambda 
serverless deploy

# postman collection
go to file : serverless_demo.postman_collection.json